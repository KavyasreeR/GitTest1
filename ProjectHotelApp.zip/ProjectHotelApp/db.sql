create database dbhotel;

GO

use dbhotel;

GO

Create table hotel(
HotelId int,
Name varchar(25),
Rating int,
Address varchar(80),
Landmark varchar(25),
City varchar(25),
Pincode int,
AC_1_Bed int,
AC_2_Bed int,
AC_3_Bed int,
NonAC_1_Bed int,
NonAC_2_Bed int,
NonAC_3_Bed int,
TotalRooms int
);

GO

Create table Booking(
HotelId int,
HotelName varchar(30),
HotelAddress varchar(80),
HotelCity varchar(20),
Beds int,
Cool varchar(8),
rooms int,
CheckInDate varchar(10),
CheckOutDate varchar(10),
UserId varchar(5),
BookingDate varchar(10),
Amount int
);

GO

create table Customer(
UserId varchar(5),
Name Varchar(25),
Email varchar(35),
Phone varchar(15),
Password varchar(30)
);

GO

insert into hotel values(17823,'King Hotel',4,'Near Waverock,Nanakramguda','Gachibowli','Hyderabad',500004,5,10,15,15,20,10,75);

GO

insert into customer values(10072,'Abhishek','abhishek363036@gmail.com','9897418126','1234');

--GO

--Select * from Hotel;

--GO

--Select * from Booking;

--GO

--Select * from Customer;

--GO

--Delete from hotel;

--GO

--Delete from Booking;

--GO

--Drop table hotel;

--GO

--Drop table booking;

--GO

--Drop table Customer;