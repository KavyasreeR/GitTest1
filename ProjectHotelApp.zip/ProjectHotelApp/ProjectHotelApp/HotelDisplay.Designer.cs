﻿namespace ProjectHotelApp
{
    partial class HotelDisplay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.nextButton = new System.Windows.Forms.Button();
            this.hotelCityLabel = new System.Windows.Forms.Label();
            this.hotelAddressLabel = new System.Windows.Forms.Label();
            this.roomChargeLabel = new System.Windows.Forms.Label();
            this.hotelNameLabel = new System.Windows.Forms.Label();
            this.ratingLabel = new System.Windows.Forms.Label();
            this.cityLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.hotelCombo = new System.Windows.Forms.ComboBox();
            this.failureLabel = new System.Windows.Forms.Label();
            this.backButton = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.nextButton);
            this.panel1.Controls.Add(this.hotelCityLabel);
            this.panel1.Controls.Add(this.hotelAddressLabel);
            this.panel1.Controls.Add(this.roomChargeLabel);
            this.panel1.Controls.Add(this.hotelNameLabel);
            this.panel1.Controls.Add(this.ratingLabel);
            this.panel1.Controls.Add(this.cityLabel);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.hotelCombo);
            this.panel1.Location = new System.Drawing.Point(41, 44);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(569, 349);
            this.panel1.TabIndex = 0;
            this.panel1.Visible = false;
            // 
            // nextButton
            // 
            this.nextButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nextButton.Location = new System.Drawing.Point(244, 278);
            this.nextButton.Name = "nextButton";
            this.nextButton.Size = new System.Drawing.Size(75, 33);
            this.nextButton.TabIndex = 8;
            this.nextButton.Text = "Next >";
            this.nextButton.UseVisualStyleBackColor = true;
            this.nextButton.Click += new System.EventHandler(this.nextButton_Click);
            // 
            // hotelCityLabel
            // 
            this.hotelCityLabel.AutoSize = true;
            this.hotelCityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hotelCityLabel.Location = new System.Drawing.Point(34, 235);
            this.hotelCityLabel.Name = "hotelCityLabel";
            this.hotelCityLabel.Size = new System.Drawing.Size(0, 16);
            this.hotelCityLabel.TabIndex = 6;
            // 
            // hotelAddressLabel
            // 
            this.hotelAddressLabel.AutoSize = true;
            this.hotelAddressLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hotelAddressLabel.Location = new System.Drawing.Point(34, 202);
            this.hotelAddressLabel.Name = "hotelAddressLabel";
            this.hotelAddressLabel.Size = new System.Drawing.Size(0, 16);
            this.hotelAddressLabel.TabIndex = 5;
            // 
            // roomChargeLabel
            // 
            this.roomChargeLabel.AutoSize = true;
            this.roomChargeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roomChargeLabel.Location = new System.Drawing.Point(34, 169);
            this.roomChargeLabel.Name = "roomChargeLabel";
            this.roomChargeLabel.Size = new System.Drawing.Size(0, 16);
            this.roomChargeLabel.TabIndex = 4;
            // 
            // hotelNameLabel
            // 
            this.hotelNameLabel.AutoSize = true;
            this.hotelNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hotelNameLabel.Location = new System.Drawing.Point(34, 137);
            this.hotelNameLabel.Name = "hotelNameLabel";
            this.hotelNameLabel.Size = new System.Drawing.Size(0, 16);
            this.hotelNameLabel.TabIndex = 3;
            // 
            // ratingLabel
            // 
            this.ratingLabel.AutoSize = true;
            this.ratingLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ratingLabel.Location = new System.Drawing.Point(294, 33);
            this.ratingLabel.Name = "ratingLabel";
            this.ratingLabel.Size = new System.Drawing.Size(0, 16);
            this.ratingLabel.TabIndex = 2;
            // 
            // cityLabel
            // 
            this.cityLabel.AutoSize = true;
            this.cityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cityLabel.Location = new System.Drawing.Point(28, 34);
            this.cityLabel.Name = "cityLabel";
            this.cityLabel.Size = new System.Drawing.Size(0, 16);
            this.cityLabel.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(34, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(241, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Select a Hotel from the list down below :";
            // 
            // hotelCombo
            // 
            this.hotelCombo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hotelCombo.FormattingEnabled = true;
            this.hotelCombo.Location = new System.Drawing.Point(34, 77);
            this.hotelCombo.Name = "hotelCombo";
            this.hotelCombo.Size = new System.Drawing.Size(502, 24);
            this.hotelCombo.TabIndex = 0;
            this.hotelCombo.SelectedIndexChanged += new System.EventHandler(this.hotelCombo_SelectedIndexChanged);
            // 
            // failureLabel
            // 
            this.failureLabel.AutoSize = true;
            this.failureLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.failureLabel.ForeColor = System.Drawing.Color.Red;
            this.failureLabel.Location = new System.Drawing.Point(38, 61);
            this.failureLabel.Name = "failureLabel";
            this.failureLabel.Size = new System.Drawing.Size(0, 16);
            this.failureLabel.TabIndex = 1;
            // 
            // backButton
            // 
            this.backButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backButton.Location = new System.Drawing.Point(285, 421);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(75, 37);
            this.backButton.TabIndex = 3;
            this.backButton.Text = "Back";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // HotelDisplay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(641, 487);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.failureLabel);
            this.Controls.Add(this.panel1);
            this.Name = "HotelDisplay";
            this.Text = "Hotel Display";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox hotelCombo;
        private System.Windows.Forms.Label cityLabel;
        private System.Windows.Forms.Label ratingLabel;
        private System.Windows.Forms.Label failureLabel;
        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.Label hotelCityLabel;
        private System.Windows.Forms.Label hotelAddressLabel;
        private System.Windows.Forms.Label roomChargeLabel;
        private System.Windows.Forms.Label hotelNameLabel;
        private System.Windows.Forms.Button nextButton;
    }
}