﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectHotelApp
{
    public partial class UserPage : Form
    {
        string city = null, userId = null;
        int rating = 0;

        public UserPage(string userId)
        {
            InitializeComponent();
            this.userId = userId;
            WelcomeUser();
        }

        // selected city
        private void cmb_City2_SelectedIndexChanged(object sender, EventArgs e)
        {
            city = cmb_City2.Text.ToString();
        }

        // selected rating
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            rating = int.Parse(comboBox2.Text.ToString());
        }

        // Navigate to Next Screen
        private void nextButton_Click(object sender, EventArgs e)
        {
            if (city != null && rating != 0)
            {
                HotelDisplay hd = new HotelDisplay(userId, city, rating);
                hd.Show();
                Close();
            }
            else
            {
                MessageBox.Show("Please select the required fields.");
            }
        }

        private void logoutButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You have logged out.");
            WelcomeScreen ws = new WelcomeScreen();
            ws.Show();
            Close();
        }

        private void searchBooking_Click(object sender, EventArgs e)
        {
            bool hasBooking = false;

            var myBookings = Database.FindBookingsByUserId(userId, ref hasBooking);

            if (hasBooking)
            {
                failureLabel.Visible = false;
                bookingComboBox.Visible = true;
                searchBooking.Visible = false;
                bookingLabel.Text = "Here are your past bookings :";

                foreach (var value in myBookings)
                {
                    bookingComboBox.Items.Add(value);
                }
            }
            else
            {
                panel2.Visible = false;
                failureLabel.Visible = true;
            }
        }

        public void WelcomeUser()
        {
            var name = Database.FindUserByIdAndReturnName(userId);
            welcomeLabel.Text = "Welcome, " + name + "!";
        }
    }
}
