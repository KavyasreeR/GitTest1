﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectHotelApp
{
    public class Database
    {
        static SqlConnection conn = null;
        static SqlCommand cmd = null;
        static SqlDataReader rdr = null;
        
        public static int AddNewHotelToDB(string hotelId, string name, string address, string landmark, string city, string rating, string pincode, string ac1, string ac2, string ac3, string nonac1, string nonac2, string nonac3, string total)
        {
            OpenConnection();
            string query = "insert into hotel(HotelId,Name,Rating,Address,Landmark,City,Pincode,AC_1_Bed,AC_2_Bed,AC_3_Bed,NonAC_1_Bed,NonAC_2_Bed,NonAC_3_Bed,TotalRooms) values(" + hotelId + ",'" + name + "'," + rating + ",'" + address + "','" + landmark + "','" + city + "'," + pincode + "," + ac1 + "," + ac2 + "," + ac3 + "," + nonac1 + "," + nonac2 + "," + nonac3 + "," + total + ")";
            CloseConnection();
            return InsertValuesToHotel(query);
        }

        public static int InsertValuesToHotel(string q)
        {
            OpenConnection();
            cmd = new SqlCommand(q, conn);
            int k = -1;
            try
            {
                k = cmd.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
            }
            CloseConnection();

            if(k == 1)
            {
                return 1;
            }
            return -1;
        }

        public static List<string> SearchHotelsWithCityAndRating(string city, int rating, ref bool hasHotel)
        {
            OpenConnection();
            string query = "select HotelId,Name,Address from hotel where city = '" + city + "' and rating = " + rating;
            cmd = new SqlCommand(query, conn);
            rdr = cmd.ExecuteReader();

            var myHotels = new List<string>();

            if (rdr.HasRows)
            {
                hasHotel = true;
                while (rdr.Read())
                {
                    myHotels.Add(rdr[0] + " " + rdr[1] + " " + rdr[2]); // Add HotelId, Name and Address of the Hotel
                }
            }
            else
            {
                hasHotel = false;
            }

            CloseConnection();
            return myHotels;
        }

        public static List<string> SelectAllHotels(ref bool hasHostel)
        {
            OpenConnection();
            string query = "select * from hotel";
            cmd = new SqlCommand(query, conn);
            rdr = cmd.ExecuteReader();

            var myHotels = new List<string>();

            if (rdr.HasRows)
            {
                hasHostel = true;
                while (rdr.Read())
                {
                    myHotels.Add(rdr[0] + " " + rdr[1] + " " + rdr[3]);
                }
            }
            else
            {
                hasHostel = false;
            }

            CloseConnection();
            return myHotels;
        }

        public static string FindHotelById(int hotelId)
        {
            OpenConnection();
            string query = "select AC_1_Bed, AC_2_Bed, AC_3_Bed, NonAC_1_Bed, NonAC_2_Bed, NonAC_3_Bed from hotel where HotelId = " + hotelId;
            cmd = new SqlCommand(query, conn);
            rdr = cmd.ExecuteReader();
            string str = null;

            if (rdr.Read())
            {
                str = rdr[0] + " " + rdr[1] + " " + rdr[2] + " " + rdr[3] + " " + rdr[4] + " " + rdr[5];
            }

            CloseConnection();
            return str;
        }

        public static bool CheckIfHotelExists(string Id)
        {
            var str = FindHotelById(int.Parse(Id));
            if(str.Length != 0)
            {
                return true;
            }
            return false;
        }

        public static string FindHotelByIdAndReturnName(int hotelId)
        {
            OpenConnection();
            string query = "select name from hotel where hotelid = " + hotelId;
            cmd = new SqlCommand(query, conn);
            rdr = cmd.ExecuteReader();
            string str = null;

            if (rdr.Read())
            {
                str = rdr[0].ToString();
            }

            CloseConnection();
            return str;
        }

        public static List<string> FindHotelByIdAndReturnNameAddressCity(int hotelId)
        {
            OpenConnection();
            string query = "select name,address,city from hotel where hotelid = " + hotelId;
            cmd = new SqlCommand(query, conn);
            rdr = cmd.ExecuteReader();

            var myHotelDetails = new List<string>();

            if (rdr.Read())
            {
                myHotelDetails.Add(rdr[0].ToString());
                myHotelDetails.Add(rdr[1].ToString());
                myHotelDetails.Add(rdr[2].ToString());
            }

            CloseConnection();
            return myHotelDetails;
        }

        public static bool CheckRoomAvailabilityById(int hotelId, int beds, string cool, int rooms)
        {
            OpenConnection();
            string query = CreateQuery(hotelId, beds, cool);
            cmd = new SqlCommand(query, conn);
            rdr = cmd.ExecuteReader();

            int room_count = -1;

            if (rdr.Read())
            {
                room_count = int.Parse(rdr[0].ToString());
            }

            CloseConnection();

            if (room_count >= rooms)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static int CreateNewBooking(int hotelId,int beds,string cool,int rooms,string cInDate,string cOutDate,string userId,string bDate,int amount)
        {
            var myHotel = FindHotelByIdAndReturnNameAddressCity(hotelId);

            OpenConnection();
            string query = "insert into booking(HotelId,HotelName,HotelAddress,HotelCity,Beds,Cool,Rooms,CheckInDate,CheckOutDate,UserId,BookingDate,Amount) values(" + hotelId + ",'" + myHotel[0].ToString() + "','" + myHotel[1].ToString() + "','" + myHotel[2].ToString() + "'," + beds + ",'" + cool + "',"+rooms+",'"+cInDate+"','"+cOutDate+"','"+userId+"','"+bDate+"',"+amount+")";
            cmd = new SqlCommand(query, conn);
            int k = cmd.ExecuteNonQuery();
            CloseConnection();

            if(k == 1)
            {
                // Code for updating the count of rooms in Hotel table
                //
                //
                //
                return 1;
            }
            return -1;
        }

        public static List<string> SelectAllBookings(ref bool hasHotel)
        {
            OpenConnection();
            string query = "select HotelName,HotelCity,Beds,Cool,Rooms,CheckInDate,CheckOutDate,UserId,BookingDate,Amount from booking";
            cmd = new SqlCommand(query, conn);
            rdr = cmd.ExecuteReader();

            var bookings = new List<string>();

            while(rdr.Read())
            {
                hasHotel = true;
                bookings.Add(rdr[0] + " " + rdr[1] + " for " + rdr[4] + " rooms " + rdr[3] + " with " + rdr[2] + " beds from " + rdr[5] + " to " + rdr[6] + " by Customer Id : " + rdr[7] + " Dated : " + rdr[8] + " at amount : Rs. " + rdr[9]);
            }

            CloseConnection();
            return bookings;
        }

        public static List<string> FindBookingsByUserId(string userId, ref bool hasBooking)
        {
            OpenConnection();
            string query = "select HotelName,HotelCity,Beds,Cool,Rooms,CheckInDate,CheckOutDate,UserId,BookingDate,Amount from booking where UserId = '" + userId + "'";
            cmd = new SqlCommand(query, conn);
            rdr = cmd.ExecuteReader();

            var myBookings = new List<string>();

            if (rdr.HasRows)
            {
                hasBooking = true;
                while (rdr.Read())
                {
                    myBookings.Add(rdr[0] + " " + rdr[1] + " for " + rdr[4] + " rooms " + rdr[3] + " with " + rdr[2] + " beds from " + rdr[5] + " to " + rdr[6] + " by Customer Id : " + rdr[7] + " Dated : " + rdr[8] + " at amount : Rs. " + rdr[9]);
                }
            }
            else
            {
                hasBooking = false;
            }

            CloseConnection();
            return myBookings;
        }

        public static int CreateNewUser(string userId,string name,string email,string phone,string password)
        {
            OpenConnection();
            string query = "insert into customer(UserId,Name,Email,Phone,Password) values('"+userId+"','"+name+"','"+email+"','"+phone+"','"+password+"')";
            cmd = new SqlCommand(query, conn);
            int k = cmd.ExecuteNonQuery();
            CloseConnection();

            if (k == 1)
            {
                return 1;
            }

            return 0;
        }

        public static bool FindUserById(string userId)
        {
            OpenConnection();
            string query = "select UserId from Customer where UserId = '" + userId + "'";
            cmd = new SqlCommand(query, conn);
            rdr = cmd.ExecuteReader();
            bool temp = false;

            if (rdr.Read())
            {
                temp = true;
            }

            CloseConnection();
            return temp;
        }

        public static string FindUserByIdAndReturnName(string userId)
        {
            OpenConnection();
            string query = "select Name from Customer where UserId = '" + userId + "'";
            cmd = new SqlCommand(query, conn);
            rdr = cmd.ExecuteReader();
            string temp = null;

            if (rdr.Read())
            {
                temp = rdr[0].ToString();
            }

            CloseConnection();
            return temp;
        }

        public static List<string> FindUserByIdAndReturnNamePhone(string userId)
        {
            OpenConnection();
            string query = "select Name,Phone from Customer where UserId = '" + userId + "'";
            cmd = new SqlCommand(query, conn);
            rdr = cmd.ExecuteReader();
            var myDetails = new List<string>();

            if (rdr.Read())
            {
                myDetails.Add(rdr[0].ToString());
                myDetails.Add(rdr[1].ToString());
            }

            CloseConnection();
            return myDetails;
        }

        public static bool CheckIfPasswordCorrect(string userId, string password)
        {
            OpenConnection();
            string query = "select Password from Customer where UserId = '" + userId + "'";
            cmd = new SqlCommand(query,conn);
            rdr = cmd.ExecuteReader();
            bool temp = false;

            if (rdr.Read())
            {
                if (rdr[0].ToString().Equals(password))
                {
                    temp = true;
                }
            }

            CloseConnection();
            return temp;
        }

        public static string CreateQuery(int hotelId, int beds, string cool)
        {
            string query = "select ";

            if (beds == 1)
            {
                if (cool.Equals("AC"))
                {
                    query += "AC_1_Bed ";
                }
                else
                {
                    query += "NonAC_1_Bed ";
                }
            }
            else if (beds == 2)
            {
                if (cool.Equals("AC"))
                {
                    query += "AC_2_Bed ";
                }
                else
                {
                    query += "NonAC_2_Bed ";
                }
            }
            else
            {
                if (cool.Equals("AC"))
                {
                    query += "AC_3_Bed ";
                }
                else
                {
                    query += "NonAC_3_Bed ";
                }
            }

            query += "from hotel where HotelId = " + hotelId;

            return query;
        }

        private static void OpenConnection()
        {
            try
            {
                conn = new SqlConnection(@"
                    Data Source=(local);
                    Initial Catalog=dbhotel;
                    Integrated Security=SSPI");
                conn.Open();
            }
            catch (Exception ex)
            {
                Console.WriteLine("EXCEPTION : " + ex.Message);
            }
        }

        private static void CloseConnection()
        {
            if (conn != null)
            {
                conn.Close();
            }
            if (rdr != null)
            {
                rdr.Close();
            }
            if (cmd != null)
            {
                cmd = null;
            }
        }
    }
}
