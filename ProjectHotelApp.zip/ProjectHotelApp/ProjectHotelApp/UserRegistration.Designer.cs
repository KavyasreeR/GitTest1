﻿namespace ProjectHotelApp
{
    partial class UserRegistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameField = new System.Windows.Forms.TextBox();
            this.emailField = new System.Windows.Forms.TextBox();
            this.phoneField = new System.Windows.Forms.TextBox();
            this.userIdField = new System.Windows.Forms.TextBox();
            this.createPassField = new System.Windows.Forms.TextBox();
            this.confirmPassField = new System.Windows.Forms.TextBox();
            this.lb_Name = new System.Windows.Forms.Label();
            this.lb_EmailId = new System.Windows.Forms.Label();
            this.lb_MobileNo = new System.Windows.Forms.Label();
            this.lb_UserId = new System.Windows.Forms.Label();
            this.lb_Pwd1 = new System.Windows.Forms.Label();
            this.lb_ConfirmPwd = new System.Windows.Forms.Label();
            this.lb_WlcmText = new System.Windows.Forms.Label();
            this.createButton = new System.Windows.Forms.Button();
            this.backButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // nameField
            // 
            this.nameField.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameField.Location = new System.Drawing.Point(283, 130);
            this.nameField.Margin = new System.Windows.Forms.Padding(4);
            this.nameField.Name = "nameField";
            this.nameField.Size = new System.Drawing.Size(356, 26);
            this.nameField.TabIndex = 0;
            // 
            // emailField
            // 
            this.emailField.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailField.Location = new System.Drawing.Point(283, 180);
            this.emailField.Margin = new System.Windows.Forms.Padding(4);
            this.emailField.Name = "emailField";
            this.emailField.Size = new System.Drawing.Size(356, 26);
            this.emailField.TabIndex = 1;
            // 
            // phoneField
            // 
            this.phoneField.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneField.Location = new System.Drawing.Point(283, 231);
            this.phoneField.Margin = new System.Windows.Forms.Padding(4);
            this.phoneField.Name = "phoneField";
            this.phoneField.Size = new System.Drawing.Size(356, 26);
            this.phoneField.TabIndex = 2;
            // 
            // userIdField
            // 
            this.userIdField.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userIdField.Location = new System.Drawing.Point(283, 281);
            this.userIdField.Margin = new System.Windows.Forms.Padding(4);
            this.userIdField.Name = "userIdField";
            this.userIdField.Size = new System.Drawing.Size(356, 26);
            this.userIdField.TabIndex = 3;
            // 
            // createPassField
            // 
            this.createPassField.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createPassField.Location = new System.Drawing.Point(283, 335);
            this.createPassField.Margin = new System.Windows.Forms.Padding(4);
            this.createPassField.Name = "createPassField";
            this.createPassField.PasswordChar = '*';
            this.createPassField.Size = new System.Drawing.Size(356, 26);
            this.createPassField.TabIndex = 4;
            // 
            // confirmPassField
            // 
            this.confirmPassField.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirmPassField.Location = new System.Drawing.Point(283, 388);
            this.confirmPassField.Margin = new System.Windows.Forms.Padding(4);
            this.confirmPassField.Name = "confirmPassField";
            this.confirmPassField.PasswordChar = '*';
            this.confirmPassField.Size = new System.Drawing.Size(356, 26);
            this.confirmPassField.TabIndex = 5;
            // 
            // lb_Name
            // 
            this.lb_Name.AutoSize = true;
            this.lb_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Name.Location = new System.Drawing.Point(77, 130);
            this.lb_Name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_Name.Name = "lb_Name";
            this.lb_Name.Size = new System.Drawing.Size(85, 20);
            this.lb_Name.TabIndex = 6;
            this.lb_Name.Text = "Full Name";
            // 
            // lb_EmailId
            // 
            this.lb_EmailId.AutoSize = true;
            this.lb_EmailId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_EmailId.Location = new System.Drawing.Point(77, 180);
            this.lb_EmailId.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_EmailId.Name = "lb_EmailId";
            this.lb_EmailId.Size = new System.Drawing.Size(51, 20);
            this.lb_EmailId.TabIndex = 7;
            this.lb_EmailId.Text = "Email";
            // 
            // lb_MobileNo
            // 
            this.lb_MobileNo.AutoSize = true;
            this.lb_MobileNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_MobileNo.Location = new System.Drawing.Point(77, 231);
            this.lb_MobileNo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_MobileNo.Name = "lb_MobileNo";
            this.lb_MobileNo.Size = new System.Drawing.Size(56, 20);
            this.lb_MobileNo.TabIndex = 8;
            this.lb_MobileNo.Text = "Phone";
            // 
            // lb_UserId
            // 
            this.lb_UserId.AutoSize = true;
            this.lb_UserId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UserId.Location = new System.Drawing.Point(77, 285);
            this.lb_UserId.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_UserId.Name = "lb_UserId";
            this.lb_UserId.Size = new System.Drawing.Size(132, 20);
            this.lb_UserId.TabIndex = 9;
            this.lb_UserId.Text = "Create a User Id";
            // 
            // lb_Pwd1
            // 
            this.lb_Pwd1.AutoSize = true;
            this.lb_Pwd1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Pwd1.Location = new System.Drawing.Point(77, 335);
            this.lb_Pwd1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_Pwd1.Name = "lb_Pwd1";
            this.lb_Pwd1.Size = new System.Drawing.Size(138, 20);
            this.lb_Pwd1.TabIndex = 10;
            this.lb_Pwd1.Text = "Create Password";
            // 
            // lb_ConfirmPwd
            // 
            this.lb_ConfirmPwd.AutoSize = true;
            this.lb_ConfirmPwd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ConfirmPwd.Location = new System.Drawing.Point(77, 388);
            this.lb_ConfirmPwd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_ConfirmPwd.Name = "lb_ConfirmPwd";
            this.lb_ConfirmPwd.Size = new System.Drawing.Size(147, 20);
            this.lb_ConfirmPwd.TabIndex = 11;
            this.lb_ConfirmPwd.Text = "Confirm Password";
            // 
            // lb_WlcmText
            // 
            this.lb_WlcmText.AutoSize = true;
            this.lb_WlcmText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_WlcmText.Location = new System.Drawing.Point(75, 68);
            this.lb_WlcmText.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_WlcmText.Name = "lb_WlcmText";
            this.lb_WlcmText.Size = new System.Drawing.Size(440, 25);
            this.lb_WlcmText.TabIndex = 14;
            this.lb_WlcmText.Text = "Enter the details given below to create an account";
            // 
            // createButton
            // 
            this.createButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createButton.Location = new System.Drawing.Point(396, 454);
            this.createButton.Margin = new System.Windows.Forms.Padding(4);
            this.createButton.Name = "createButton";
            this.createButton.Size = new System.Drawing.Size(145, 41);
            this.createButton.TabIndex = 15;
            this.createButton.Text = "Create account";
            this.createButton.UseVisualStyleBackColor = true;
            this.createButton.Click += new System.EventHandler(this.createButton_Click);
            // 
            // backButton
            // 
            this.backButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backButton.Location = new System.Drawing.Point(149, 454);
            this.backButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(75, 41);
            this.backButton.TabIndex = 16;
            this.backButton.Text = "Back";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // UserRegistration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1098, 548);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.createButton);
            this.Controls.Add(this.lb_WlcmText);
            this.Controls.Add(this.lb_ConfirmPwd);
            this.Controls.Add(this.lb_Pwd1);
            this.Controls.Add(this.lb_UserId);
            this.Controls.Add(this.lb_MobileNo);
            this.Controls.Add(this.lb_EmailId);
            this.Controls.Add(this.lb_Name);
            this.Controls.Add(this.confirmPassField);
            this.Controls.Add(this.createPassField);
            this.Controls.Add(this.userIdField);
            this.Controls.Add(this.phoneField);
            this.Controls.Add(this.emailField);
            this.Controls.Add(this.nameField);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "UserRegistration";
            this.Text = "User Registration Page";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox nameField;
        private System.Windows.Forms.TextBox emailField;
        private System.Windows.Forms.TextBox phoneField;
        private System.Windows.Forms.TextBox userIdField;
        private System.Windows.Forms.TextBox createPassField;
        private System.Windows.Forms.TextBox confirmPassField;
        private System.Windows.Forms.Label lb_Name;
        private System.Windows.Forms.Label lb_EmailId;
        private System.Windows.Forms.Label lb_MobileNo;
        private System.Windows.Forms.Label lb_UserId;
        private System.Windows.Forms.Label lb_Pwd1;
        private System.Windows.Forms.Label lb_ConfirmPwd;
        private System.Windows.Forms.Label lb_WlcmText;
        private System.Windows.Forms.Button createButton;
        private System.Windows.Forms.Button backButton;
    }
}