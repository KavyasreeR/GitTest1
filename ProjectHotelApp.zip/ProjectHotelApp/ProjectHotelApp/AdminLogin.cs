﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectHotelApp
{
    public partial class AdminLogin : Form
    {
        int attempts;

        public AdminLogin()
        {
            InitializeComponent();
            attempts = 3;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var user = textBox1.Text.ToString();
            var pass = textBox2.Text; // Allow special characters to come

            if (user.Equals("admin") && attempts > 0)
            {
                if (pass.Equals("admin@123"))
                {
                    // Open admin page
                    AdminPage adminPage = new AdminPage();
                    adminPage.Show();
                    Hide();
                }
                else
                {
                    attempts -= 1;
                    if (attempts == 0)
                    {
                        MessageBox.Show("All attempts failed, Redirecting to Welcome Page.");
                        WelcomeScreen ws = new WelcomeScreen();
                        ws.Show();
                        Close();
                    }
                    if (attempts > 0)
                    {
                        MessageBox.Show("ALERT: Wrong password, Attempts remain : " + attempts);
                    }
                }
            }
            else
            {
                MessageBox.Show("User does not exist.");
            }
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            WelcomeScreen ws = new WelcomeScreen();
            ws.Show();
            Close();
        }
    }
}
