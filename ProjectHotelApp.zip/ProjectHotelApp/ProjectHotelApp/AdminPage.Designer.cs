﻿namespace ProjectHotelApp
{
    partial class AdminPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.selectHotelCombo = new System.Windows.Forms.ComboBox();
            this.acroom1 = new System.Windows.Forms.Label();
            this.acroom2 = new System.Windows.Forms.Label();
            this.acroom3 = new System.Windows.Forms.Label();
            this.nonacroom1 = new System.Windows.Forms.Label();
            this.nonacroom2 = new System.Windows.Forms.Label();
            this.nonacroom3 = new System.Windows.Forms.Label();
            this.totalRooms = new System.Windows.Forms.Label();
            this.resultBox = new System.Windows.Forms.GroupBox();
            this.bookingPanel = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.customerBookingBox = new System.Windows.Forms.ComboBox();
            this.bookingsButton = new System.Windows.Forms.Button();
            this.failureLabel = new System.Windows.Forms.Label();
            this.resultBox.SuspendLayout();
            this.bookingPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Welcome, Admin!";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(478, 13);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 28);
            this.button1.TabIndex = 1;
            this.button1.Text = "Logout";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(28, 429);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(525, 34);
            this.button3.TabIndex = 8;
            this.button3.Text = "Add a New Hotel";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(24, 176);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(448, 18);
            this.label3.TabIndex = 11;
            this.label3.Text = "Select a hotel from the list below to see the no. of rooms available :";
            // 
            // selectHotelCombo
            // 
            this.selectHotelCombo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectHotelCombo.FormattingEnabled = true;
            this.selectHotelCombo.Location = new System.Drawing.Point(28, 210);
            this.selectHotelCombo.Margin = new System.Windows.Forms.Padding(2);
            this.selectHotelCombo.Name = "selectHotelCombo";
            this.selectHotelCombo.Size = new System.Drawing.Size(525, 25);
            this.selectHotelCombo.TabIndex = 12;
            this.selectHotelCombo.Visible = false;
            this.selectHotelCombo.SelectedIndexChanged += new System.EventHandler(this.selectHotelCombo_SelectedIndexChanged);
            // 
            // acroom1
            // 
            this.acroom1.AutoSize = true;
            this.acroom1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acroom1.Location = new System.Drawing.Point(44, 31);
            this.acroom1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.acroom1.Name = "acroom1";
            this.acroom1.Size = new System.Drawing.Size(0, 15);
            this.acroom1.TabIndex = 13;
            // 
            // acroom2
            // 
            this.acroom2.AutoSize = true;
            this.acroom2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acroom2.Location = new System.Drawing.Point(44, 64);
            this.acroom2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.acroom2.Name = "acroom2";
            this.acroom2.Size = new System.Drawing.Size(0, 15);
            this.acroom2.TabIndex = 14;
            // 
            // acroom3
            // 
            this.acroom3.AutoSize = true;
            this.acroom3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acroom3.Location = new System.Drawing.Point(44, 97);
            this.acroom3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.acroom3.Name = "acroom3";
            this.acroom3.Size = new System.Drawing.Size(0, 15);
            this.acroom3.TabIndex = 15;
            // 
            // nonacroom1
            // 
            this.nonacroom1.AutoSize = true;
            this.nonacroom1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nonacroom1.Location = new System.Drawing.Point(281, 31);
            this.nonacroom1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.nonacroom1.Name = "nonacroom1";
            this.nonacroom1.Size = new System.Drawing.Size(0, 15);
            this.nonacroom1.TabIndex = 16;
            // 
            // nonacroom2
            // 
            this.nonacroom2.AutoSize = true;
            this.nonacroom2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nonacroom2.Location = new System.Drawing.Point(281, 64);
            this.nonacroom2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.nonacroom2.Name = "nonacroom2";
            this.nonacroom2.Size = new System.Drawing.Size(0, 15);
            this.nonacroom2.TabIndex = 17;
            // 
            // nonacroom3
            // 
            this.nonacroom3.AutoSize = true;
            this.nonacroom3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nonacroom3.Location = new System.Drawing.Point(281, 97);
            this.nonacroom3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.nonacroom3.Name = "nonacroom3";
            this.nonacroom3.Size = new System.Drawing.Size(0, 15);
            this.nonacroom3.TabIndex = 18;
            // 
            // totalRooms
            // 
            this.totalRooms.AutoSize = true;
            this.totalRooms.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalRooms.Location = new System.Drawing.Point(43, 129);
            this.totalRooms.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.totalRooms.Name = "totalRooms";
            this.totalRooms.Size = new System.Drawing.Size(0, 17);
            this.totalRooms.TabIndex = 19;
            // 
            // resultBox
            // 
            this.resultBox.Controls.Add(this.acroom1);
            this.resultBox.Controls.Add(this.totalRooms);
            this.resultBox.Controls.Add(this.acroom2);
            this.resultBox.Controls.Add(this.nonacroom3);
            this.resultBox.Controls.Add(this.acroom3);
            this.resultBox.Controls.Add(this.nonacroom2);
            this.resultBox.Controls.Add(this.nonacroom1);
            this.resultBox.Location = new System.Drawing.Point(28, 249);
            this.resultBox.Margin = new System.Windows.Forms.Padding(2);
            this.resultBox.Name = "resultBox";
            this.resultBox.Padding = new System.Windows.Forms.Padding(2);
            this.resultBox.Size = new System.Drawing.Size(525, 167);
            this.resultBox.TabIndex = 20;
            this.resultBox.TabStop = false;
            this.resultBox.Text = "Results";
            this.resultBox.Visible = false;
            // 
            // bookingPanel
            // 
            this.bookingPanel.Controls.Add(this.label2);
            this.bookingPanel.Controls.Add(this.customerBookingBox);
            this.bookingPanel.Controls.Add(this.bookingsButton);
            this.bookingPanel.Location = new System.Drawing.Point(0, 70);
            this.bookingPanel.Name = "bookingPanel";
            this.bookingPanel.Size = new System.Drawing.Size(577, 103);
            this.bookingPanel.TabIndex = 21;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(26, 21);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(275, 18);
            this.label2.TabIndex = 13;
            this.label2.Text = "To see the Customer Bookings you may";
            // 
            // customerBookingBox
            // 
            this.customerBookingBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerBookingBox.FormattingEnabled = true;
            this.customerBookingBox.Location = new System.Drawing.Point(28, 61);
            this.customerBookingBox.Name = "customerBookingBox";
            this.customerBookingBox.Size = new System.Drawing.Size(525, 25);
            this.customerBookingBox.TabIndex = 12;
            this.customerBookingBox.Visible = false;
            // 
            // bookingsButton
            // 
            this.bookingsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookingsButton.Location = new System.Drawing.Point(313, 17);
            this.bookingsButton.Name = "bookingsButton";
            this.bookingsButton.Size = new System.Drawing.Size(95, 27);
            this.bookingsButton.TabIndex = 11;
            this.bookingsButton.Text = "Click Here";
            this.bookingsButton.UseVisualStyleBackColor = true;
            this.bookingsButton.Click += new System.EventHandler(this.bookingsButton_Click);
            // 
            // failureLabel
            // 
            this.failureLabel.AutoSize = true;
            this.failureLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.failureLabel.ForeColor = System.Drawing.Color.Red;
            this.failureLabel.Location = new System.Drawing.Point(25, 104);
            this.failureLabel.Name = "failureLabel";
            this.failureLabel.Size = new System.Drawing.Size(0, 16);
            this.failureLabel.TabIndex = 14;
            // 
            // AdminPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(576, 501);
            this.Controls.Add(this.failureLabel);
            this.Controls.Add(this.bookingPanel);
            this.Controls.Add(this.resultBox);
            this.Controls.Add(this.selectHotelCombo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Name = "AdminPage";
            this.Text = "AdminPage";
            this.resultBox.ResumeLayout(false);
            this.resultBox.PerformLayout();
            this.bookingPanel.ResumeLayout(false);
            this.bookingPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox selectHotelCombo;
        private System.Windows.Forms.Label acroom1;
        private System.Windows.Forms.Label acroom2;
        private System.Windows.Forms.Label acroom3;
        private System.Windows.Forms.Label nonacroom1;
        private System.Windows.Forms.Label nonacroom2;
        private System.Windows.Forms.Label nonacroom3;
        private System.Windows.Forms.Label totalRooms;
        private System.Windows.Forms.GroupBox resultBox;
        private System.Windows.Forms.Panel bookingPanel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox customerBookingBox;
        private System.Windows.Forms.Button bookingsButton;
        private System.Windows.Forms.Label failureLabel;
    }
}