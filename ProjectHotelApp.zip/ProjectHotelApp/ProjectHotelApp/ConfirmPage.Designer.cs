﻿namespace ProjectHotelApp
{
    partial class ConfirmPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.hotelNameLabel = new System.Windows.Forms.Label();
            this.hotelAddress = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.hotelCityName = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.bookingBeds = new System.Windows.Forms.Label();
            this.bookingRooms = new System.Windows.Forms.Label();
            this.bookingCool = new System.Windows.Forms.Label();
            this.bookingCheckIn = new System.Windows.Forms.Label();
            this.bookingCheckOut = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.customerName = new System.Windows.Forms.Label();
            this.customerPhone = new System.Windows.Forms.Label();
            this.payLabel = new System.Windows.Forms.Label();
            this.bookingLabel = new System.Windows.Forms.Label();
            this.payLabelAmount = new System.Windows.Forms.Label();
            this.bookingDateLabel = new System.Windows.Forms.Label();
            this.confirmBooking = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(54, 32);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(392, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Please verify these details again and confirm your booking.";
            // 
            // hotelNameLabel
            // 
            this.hotelNameLabel.AutoSize = true;
            this.hotelNameLabel.BackColor = System.Drawing.SystemColors.Window;
            this.hotelNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hotelNameLabel.Location = new System.Drawing.Point(86, 94);
            this.hotelNameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.hotelNameLabel.Name = "hotelNameLabel";
            this.hotelNameLabel.Size = new System.Drawing.Size(50, 15);
            this.hotelNameLabel.TabIndex = 1;
            this.hotelNameLabel.Text = "Name : ";
            // 
            // hotelAddress
            // 
            this.hotelAddress.AutoSize = true;
            this.hotelAddress.BackColor = System.Drawing.SystemColors.Window;
            this.hotelAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hotelAddress.Location = new System.Drawing.Point(86, 120);
            this.hotelAddress.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.hotelAddress.Name = "hotelAddress";
            this.hotelAddress.Size = new System.Drawing.Size(60, 15);
            this.hotelAddress.TabIndex = 2;
            this.hotelAddress.Text = "Address : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(54, 67);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Hotel Details :";
            // 
            // hotelCityName
            // 
            this.hotelCityName.AutoSize = true;
            this.hotelCityName.BackColor = System.Drawing.SystemColors.Window;
            this.hotelCityName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hotelCityName.Location = new System.Drawing.Point(86, 150);
            this.hotelCityName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.hotelCityName.Name = "hotelCityName";
            this.hotelCityName.Size = new System.Drawing.Size(35, 15);
            this.hotelCityName.TabIndex = 4;
            this.hotelCityName.Text = "City : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(55, 188);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Booking Details :";
            // 
            // bookingBeds
            // 
            this.bookingBeds.AutoSize = true;
            this.bookingBeds.BackColor = System.Drawing.SystemColors.Window;
            this.bookingBeds.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookingBeds.Location = new System.Drawing.Point(86, 219);
            this.bookingBeds.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bookingBeds.Name = "bookingBeds";
            this.bookingBeds.Size = new System.Drawing.Size(79, 15);
            this.bookingBeds.TabIndex = 7;
            this.bookingBeds.Text = "No. of Beds : ";
            // 
            // bookingRooms
            // 
            this.bookingRooms.AutoSize = true;
            this.bookingRooms.BackColor = System.Drawing.SystemColors.Window;
            this.bookingRooms.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookingRooms.Location = new System.Drawing.Point(84, 248);
            this.bookingRooms.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bookingRooms.Name = "bookingRooms";
            this.bookingRooms.Size = new System.Drawing.Size(91, 15);
            this.bookingRooms.TabIndex = 8;
            this.bookingRooms.Text = "No. of Rooms : ";
            // 
            // bookingCool
            // 
            this.bookingCool.AutoSize = true;
            this.bookingCool.BackColor = System.Drawing.SystemColors.Window;
            this.bookingCool.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookingCool.Location = new System.Drawing.Point(84, 276);
            this.bookingCool.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bookingCool.Name = "bookingCool";
            this.bookingCool.Size = new System.Drawing.Size(76, 15);
            this.bookingCool.TabIndex = 9;
            this.bookingCool.Text = "AC/Non-AC : ";
            // 
            // bookingCheckIn
            // 
            this.bookingCheckIn.AutoSize = true;
            this.bookingCheckIn.BackColor = System.Drawing.SystemColors.Window;
            this.bookingCheckIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookingCheckIn.Location = new System.Drawing.Point(84, 307);
            this.bookingCheckIn.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bookingCheckIn.Name = "bookingCheckIn";
            this.bookingCheckIn.Size = new System.Drawing.Size(91, 15);
            this.bookingCheckIn.TabIndex = 10;
            this.bookingCheckIn.Text = "Check-in date : ";
            // 
            // bookingCheckOut
            // 
            this.bookingCheckOut.AutoSize = true;
            this.bookingCheckOut.BackColor = System.Drawing.SystemColors.Window;
            this.bookingCheckOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookingCheckOut.Location = new System.Drawing.Point(84, 340);
            this.bookingCheckOut.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bookingCheckOut.Name = "bookingCheckOut";
            this.bookingCheckOut.Size = new System.Drawing.Size(98, 15);
            this.bookingCheckOut.TabIndex = 11;
            this.bookingCheckOut.Text = "Check-out date : ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(55, 373);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(141, 17);
            this.label9.TabIndex = 12;
            this.label9.Text = "Customer Details :";
            // 
            // customerName
            // 
            this.customerName.AutoSize = true;
            this.customerName.BackColor = System.Drawing.SystemColors.Window;
            this.customerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerName.Location = new System.Drawing.Point(83, 401);
            this.customerName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.customerName.Name = "customerName";
            this.customerName.Size = new System.Drawing.Size(50, 15);
            this.customerName.TabIndex = 13;
            this.customerName.Text = "Name : ";
            // 
            // customerPhone
            // 
            this.customerPhone.AutoSize = true;
            this.customerPhone.BackColor = System.Drawing.SystemColors.Window;
            this.customerPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerPhone.Location = new System.Drawing.Point(83, 431);
            this.customerPhone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.customerPhone.Name = "customerPhone";
            this.customerPhone.Size = new System.Drawing.Size(52, 15);
            this.customerPhone.TabIndex = 14;
            this.customerPhone.Text = "Phone : ";
            // 
            // payLabel
            // 
            this.payLabel.AutoSize = true;
            this.payLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.payLabel.Location = new System.Drawing.Point(58, 479);
            this.payLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.payLabel.Name = "payLabel";
            this.payLabel.Size = new System.Drawing.Size(137, 17);
            this.payLabel.TabIndex = 15;
            this.payLabel.Text = "Pay at Check-in : ";
            // 
            // bookingLabel
            // 
            this.bookingLabel.AutoSize = true;
            this.bookingLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookingLabel.Location = new System.Drawing.Point(60, 514);
            this.bookingLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bookingLabel.Name = "bookingLabel";
            this.bookingLabel.Size = new System.Drawing.Size(120, 17);
            this.bookingLabel.TabIndex = 16;
            this.bookingLabel.Text = "Booking Date : ";
            // 
            // payLabelAmount
            // 
            this.payLabelAmount.AutoSize = true;
            this.payLabelAmount.BackColor = System.Drawing.SystemColors.Window;
            this.payLabelAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.payLabelAmount.Location = new System.Drawing.Point(190, 481);
            this.payLabelAmount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.payLabelAmount.Name = "payLabelAmount";
            this.payLabelAmount.Size = new System.Drawing.Size(0, 17);
            this.payLabelAmount.TabIndex = 17;
            // 
            // bookingDateLabel
            // 
            this.bookingDateLabel.AutoSize = true;
            this.bookingDateLabel.BackColor = System.Drawing.SystemColors.Window;
            this.bookingDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookingDateLabel.Location = new System.Drawing.Point(169, 514);
            this.bookingDateLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bookingDateLabel.Name = "bookingDateLabel";
            this.bookingDateLabel.Size = new System.Drawing.Size(0, 17);
            this.bookingDateLabel.TabIndex = 18;
            // 
            // confirmBooking
            // 
            this.confirmBooking.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirmBooking.Location = new System.Drawing.Point(419, 578);
            this.confirmBooking.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.confirmBooking.Name = "confirmBooking";
            this.confirmBooking.Size = new System.Drawing.Size(66, 37);
            this.confirmBooking.TabIndex = 19;
            this.confirmBooking.Text = "Confirm";
            this.confirmBooking.UseVisualStyleBackColor = true;
            this.confirmBooking.Click += new System.EventHandler(this.confirmBooking_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelButton.Location = new System.Drawing.Point(116, 578);
            this.cancelButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(76, 37);
            this.cancelButton.TabIndex = 20;
            this.cancelButton.Text = "Cancel X";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // ConfirmPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(593, 676);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.confirmBooking);
            this.Controls.Add(this.bookingDateLabel);
            this.Controls.Add(this.payLabelAmount);
            this.Controls.Add(this.bookingLabel);
            this.Controls.Add(this.payLabel);
            this.Controls.Add(this.customerPhone);
            this.Controls.Add(this.customerName);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.bookingCheckOut);
            this.Controls.Add(this.bookingCheckIn);
            this.Controls.Add(this.bookingCool);
            this.Controls.Add(this.bookingRooms);
            this.Controls.Add(this.bookingBeds);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.hotelCityName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.hotelAddress);
            this.Controls.Add(this.hotelNameLabel);
            this.Controls.Add(this.label1);
            this.Name = "ConfirmPage";
            this.Text = "Confirmation Page";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label hotelNameLabel;
        private System.Windows.Forms.Label hotelAddress;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label hotelCityName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label bookingBeds;
        private System.Windows.Forms.Label bookingRooms;
        private System.Windows.Forms.Label bookingCool;
        private System.Windows.Forms.Label bookingCheckIn;
        private System.Windows.Forms.Label bookingCheckOut;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label customerName;
        private System.Windows.Forms.Label customerPhone;
        private System.Windows.Forms.Label payLabel;
        private System.Windows.Forms.Label bookingLabel;
        private System.Windows.Forms.Label payLabelAmount;
        private System.Windows.Forms.Label bookingDateLabel;
        private System.Windows.Forms.Button confirmBooking;
        private System.Windows.Forms.Button cancelButton;
    }
}