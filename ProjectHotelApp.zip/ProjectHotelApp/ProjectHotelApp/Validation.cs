﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ProjectHotelApp
{
    public class Validation
    {
        public static bool ValidateName(string name)
        {
            var regex = @"^[A-Za-z ]+$";
            var r = new Regex(regex);
            var m = r.Match(name);
            if (m.Success)
            {
                return true;
            }
            return false;
        }

        public static bool ValidateEmail(string email)
        {
            var regex = @"^[a-zA-Z]+[a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]*[@][a-zA-Z]+[.][a-zA-Z]+$";
            var r = new Regex(regex);
            var m = r.Match(email);
            if (m.Success)
            {
                return true;
            }
            return false;
        }

        public static bool ValidatePhone(string phone)
        {
            var regex = @"^[+91]?[0-9]{10}$";
            var r = new Regex(regex);
            var m = r.Match(phone);
            if (m.Success)
            {
                return true;
            }
            return false;
        }

        public static bool ValidateId(string Id)
        {
            var regex = @"^[0-9]{5}$";
            var r = new Regex(regex);
            var m = r.Match(Id);
            if (m.Success)
            {
                return true;
            }
            return false;
        }

        public static bool ValidatePasswords(string pass1, string pass2)
        {
            if (pass1.Equals(pass2))
            {
                return true;
            }
            return false;
        }

        public static bool ValidatePincode(string pin)
        {
            var regex = @"^[0-9]{6}$";
            var r = new Regex(regex);
            var m = r.Match(pin);
            if (m.Success)
            {
                return true;
            }
            return false;
        }

        public static bool ValidateAddress(string address)
        {
            var regex = @"^[A-Za-z0-9\.\,\-\ ]+$";
            var r = new Regex(regex);
            var m = r.Match(address);
            if (m.Success)
            {
                return true;
            }
            return false;
        }

        public static bool ValidateRoomNumber(List<string> myRooms, ref int wrongItem)
        {
            var regex = @"^[0-9]+$";
            var r = new Regex(regex);

            foreach(var value in myRooms)
            {
                var m = r.Match(value);
                if(m.Success)
                {
                    wrongItem += 1;
                }
                else
                {
                    return false;
                }
            }
            return true;
        }

        public static bool ValidateCheckInDate(DateTime cin)
        {
            var currDate = DateTime.Now; ;
            if(cin.ToShortDateString().Equals(currDate.ToShortDateString()))
            {
                return true;
            }
            return false;
        }

        public static bool ValidateCheckOutDate(DateTime cin, DateTime cout)
        {
            if(cin < cout)
            {
                return true;
            }
            return false;
        }
    }
}
