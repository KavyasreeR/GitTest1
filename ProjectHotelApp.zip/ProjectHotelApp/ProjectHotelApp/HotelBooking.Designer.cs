﻿namespace ProjectHotelApp
{
    partial class HotelBooking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cancelButton = new System.Windows.Forms.Button();
            this.successPanel = new System.Windows.Forms.Panel();
            this.resetDates = new System.Windows.Forms.Button();
            this.checkOutDateLabel = new System.Windows.Forms.Label();
            this.checkInDateLabel = new System.Windows.Forms.Label();
            this.checkOutButton = new System.Windows.Forms.Button();
            this.checkInButton = new System.Windows.Forms.Button();
            this.selectDateLabel = new System.Windows.Forms.Label();
            this.Calendar = new System.Windows.Forms.MonthCalendar();
            this.nextButton = new System.Windows.Forms.Button();
            this.hotelNameLabel = new System.Windows.Forms.Label();
            this.Cmb_Room = new System.Windows.Forms.ComboBox();
            this.Cmb_Cool = new System.Windows.Forms.ComboBox();
            this.Cmb_Beds = new System.Windows.Forms.ComboBox();
            this.failureLabel = new System.Windows.Forms.Label();
            this.searchButton = new System.Windows.Forms.Button();
            this.successPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // cancelButton
            // 
            this.cancelButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelButton.Location = new System.Drawing.Point(336, 637);
            this.cancelButton.Margin = new System.Windows.Forms.Padding(4);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(100, 49);
            this.cancelButton.TabIndex = 9;
            this.cancelButton.Text = "Cancel X";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // successPanel
            // 
            this.successPanel.Controls.Add(this.resetDates);
            this.successPanel.Controls.Add(this.checkOutDateLabel);
            this.successPanel.Controls.Add(this.checkInDateLabel);
            this.successPanel.Controls.Add(this.checkOutButton);
            this.successPanel.Controls.Add(this.checkInButton);
            this.successPanel.Controls.Add(this.selectDateLabel);
            this.successPanel.Controls.Add(this.Calendar);
            this.successPanel.Controls.Add(this.nextButton);
            this.successPanel.Location = new System.Drawing.Point(60, 168);
            this.successPanel.Margin = new System.Windows.Forms.Padding(4);
            this.successPanel.Name = "successPanel";
            this.successPanel.Size = new System.Drawing.Size(652, 452);
            this.successPanel.TabIndex = 18;
            this.successPanel.Visible = false;
            // 
            // resetDates
            // 
            this.resetDates.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resetDates.Location = new System.Drawing.Point(64, 373);
            this.resetDates.Name = "resetDates";
            this.resetDates.Size = new System.Drawing.Size(191, 53);
            this.resetDates.TabIndex = 17;
            this.resetDates.Text = "Reset / Change Dates";
            this.resetDates.UseVisualStyleBackColor = true;
            this.resetDates.Visible = false;
            this.resetDates.Click += new System.EventHandler(this.resetDates_Click);
            // 
            // checkOutDateLabel
            // 
            this.checkOutDateLabel.AutoSize = true;
            this.checkOutDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkOutDateLabel.Location = new System.Drawing.Point(332, 321);
            this.checkOutDateLabel.Name = "checkOutDateLabel";
            this.checkOutDateLabel.Size = new System.Drawing.Size(0, 20);
            this.checkOutDateLabel.TabIndex = 16;
            this.checkOutDateLabel.Visible = false;
            // 
            // checkInDateLabel
            // 
            this.checkInDateLabel.AutoSize = true;
            this.checkInDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkInDateLabel.Location = new System.Drawing.Point(64, 321);
            this.checkInDateLabel.Name = "checkInDateLabel";
            this.checkInDateLabel.Size = new System.Drawing.Size(0, 20);
            this.checkInDateLabel.TabIndex = 15;
            this.checkInDateLabel.UseWaitCursor = true;
            this.checkInDateLabel.Visible = false;
            // 
            // checkOutButton
            // 
            this.checkOutButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkOutButton.Location = new System.Drawing.Point(425, 202);
            this.checkOutButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkOutButton.Name = "checkOutButton";
            this.checkOutButton.Size = new System.Drawing.Size(163, 59);
            this.checkOutButton.TabIndex = 14;
            this.checkOutButton.Text = "Confirm Check-out date";
            this.checkOutButton.UseVisualStyleBackColor = true;
            this.checkOutButton.Visible = false;
            this.checkOutButton.Click += new System.EventHandler(this.checkOutButton_Click);
            // 
            // checkInButton
            // 
            this.checkInButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkInButton.Location = new System.Drawing.Point(425, 121);
            this.checkInButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkInButton.Name = "checkInButton";
            this.checkInButton.Size = new System.Drawing.Size(163, 57);
            this.checkInButton.TabIndex = 13;
            this.checkInButton.Text = "Confirm Check-in date";
            this.checkInButton.UseVisualStyleBackColor = true;
            this.checkInButton.Click += new System.EventHandler(this.checkInButton_Click);
            // 
            // selectDateLabel
            // 
            this.selectDateLabel.AutoSize = true;
            this.selectDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectDateLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.selectDateLabel.Location = new System.Drawing.Point(60, 34);
            this.selectDateLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.selectDateLabel.Name = "selectDateLabel";
            this.selectDateLabel.Size = new System.Drawing.Size(408, 24);
            this.selectDateLabel.TabIndex = 12;
            this.selectDateLabel.Text = "Please select the Check in and Check out dates";
            // 
            // Calendar
            // 
            this.Calendar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calendar.Location = new System.Drawing.Point(64, 87);
            this.Calendar.Margin = new System.Windows.Forms.Padding(12, 11, 12, 11);
            this.Calendar.Name = "Calendar";
            this.Calendar.TabIndex = 2;
            // 
            // nextButton
            // 
            this.nextButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nextButton.Location = new System.Drawing.Point(488, 373);
            this.nextButton.Margin = new System.Windows.Forms.Padding(4);
            this.nextButton.Name = "nextButton";
            this.nextButton.Size = new System.Drawing.Size(100, 53);
            this.nextButton.TabIndex = 8;
            this.nextButton.Text = "Next >";
            this.nextButton.UseVisualStyleBackColor = true;
            this.nextButton.Visible = false;
            this.nextButton.Click += new System.EventHandler(this.nextButton_Click);
            // 
            // hotelNameLabel
            // 
            this.hotelNameLabel.AutoSize = true;
            this.hotelNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hotelNameLabel.Location = new System.Drawing.Point(53, 54);
            this.hotelNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.hotelNameLabel.Name = "hotelNameLabel";
            this.hotelNameLabel.Size = new System.Drawing.Size(0, 29);
            this.hotelNameLabel.TabIndex = 17;
            // 
            // Cmb_Room
            // 
            this.Cmb_Room.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cmb_Room.FormattingEnabled = true;
            this.Cmb_Room.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.Cmb_Room.Location = new System.Drawing.Point(425, 107);
            this.Cmb_Room.Margin = new System.Windows.Forms.Padding(4);
            this.Cmb_Room.Name = "Cmb_Room";
            this.Cmb_Room.Size = new System.Drawing.Size(133, 28);
            this.Cmb_Room.TabIndex = 16;
            this.Cmb_Room.Text = "Select rooms";
            this.Cmb_Room.SelectedIndexChanged += new System.EventHandler(this.Cmb_Room_SelectedIndexChanged_1);
            // 
            // Cmb_Cool
            // 
            this.Cmb_Cool.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cmb_Cool.FormattingEnabled = true;
            this.Cmb_Cool.Items.AddRange(new object[] {
            "AC",
            "Non-AC"});
            this.Cmb_Cool.Location = new System.Drawing.Point(241, 107);
            this.Cmb_Cool.Margin = new System.Windows.Forms.Padding(4);
            this.Cmb_Cool.Name = "Cmb_Cool";
            this.Cmb_Cool.Size = new System.Drawing.Size(132, 28);
            this.Cmb_Cool.TabIndex = 15;
            this.Cmb_Cool.Text = "AC/NonAC";
            this.Cmb_Cool.SelectedIndexChanged += new System.EventHandler(this.Cmb_Cool_SelectedIndexChanged_1);
            // 
            // Cmb_Beds
            // 
            this.Cmb_Beds.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cmb_Beds.FormattingEnabled = true;
            this.Cmb_Beds.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
            this.Cmb_Beds.Location = new System.Drawing.Point(59, 107);
            this.Cmb_Beds.Margin = new System.Windows.Forms.Padding(4);
            this.Cmb_Beds.Name = "Cmb_Beds";
            this.Cmb_Beds.Size = new System.Drawing.Size(129, 28);
            this.Cmb_Beds.TabIndex = 14;
            this.Cmb_Beds.Text = "Select Beds";
            this.Cmb_Beds.SelectedIndexChanged += new System.EventHandler(this.Cmb_Beds_SelectedIndexChanged_1);
            // 
            // failureLabel
            // 
            this.failureLabel.AutoSize = true;
            this.failureLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.failureLabel.ForeColor = System.Drawing.Color.Red;
            this.failureLabel.Location = new System.Drawing.Point(104, 204);
            this.failureLabel.Name = "failureLabel";
            this.failureLabel.Size = new System.Drawing.Size(543, 24);
            this.failureLabel.TabIndex = 19;
            this.failureLabel.Text = "Sorry we currently have no services matching the above criteria.";
            this.failureLabel.Visible = false;
            // 
            // searchButton
            // 
            this.searchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchButton.Location = new System.Drawing.Point(611, 107);
            this.searchButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(101, 36);
            this.searchButton.TabIndex = 20;
            this.searchButton.Text = "Search";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // HotelBooking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(779, 711);
            this.Controls.Add(this.searchButton);
            this.Controls.Add(this.failureLabel);
            this.Controls.Add(this.successPanel);
            this.Controls.Add(this.hotelNameLabel);
            this.Controls.Add(this.Cmb_Room);
            this.Controls.Add(this.Cmb_Cool);
            this.Controls.Add(this.Cmb_Beds);
            this.Controls.Add(this.cancelButton);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "HotelBooking";
            this.Text = "Form1";
            this.successPanel.ResumeLayout(false);
            this.successPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.Panel successPanel;
        private System.Windows.Forms.Label selectDateLabel;
        private System.Windows.Forms.MonthCalendar Calendar;
        private System.Windows.Forms.Button nextButton;
        private System.Windows.Forms.Label hotelNameLabel;
        private System.Windows.Forms.ComboBox Cmb_Room;
        private System.Windows.Forms.ComboBox Cmb_Cool;
        private System.Windows.Forms.ComboBox Cmb_Beds;
        private System.Windows.Forms.Label failureLabel;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.Button checkInButton;
        private System.Windows.Forms.Button checkOutButton;
        private System.Windows.Forms.Button resetDates;
        private System.Windows.Forms.Label checkOutDateLabel;
        private System.Windows.Forms.Label checkInDateLabel;
    }
}

