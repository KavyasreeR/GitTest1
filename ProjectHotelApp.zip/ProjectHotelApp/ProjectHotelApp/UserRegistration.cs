﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectHotelApp
{
    public partial class UserRegistration : Form
    {
        string name = null, email = null, password1 = null, password2 = null, phone = null, userId = null;

        public UserRegistration()
        {
            InitializeComponent();
        }

        private void createButton_Click(object sender, EventArgs e)
        {
            InitializeValues();

            bool isValid = CheckForNullValues(); // true if all fields have some value

            if (isValid)
            {
                isValid = ValidateValues();

                if (isValid)
                {
                    isValid = Database.FindUserById(userId); // return true if ID already exists

                    if (!(isValid)) // If no user exists with that Id
                    {
                        int k = Database.CreateNewUser(userId, name, email, phone, password1);

                        if (k == 1)
                        {
                            MessageBox.Show("Successfully created account! Please login.");
                            WelcomeScreen ws = new WelcomeScreen();
                            ws.Show();
                            Close();
                        }
                        else
                        {
                            MessageBox.Show("Sorry an error occurred.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("User Id already taken.");
                        userIdField.Text = null;
                    }
                }
            }
            else
            {
                MessageBox.Show("All fields are mandatory");
            }
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            WelcomeScreen ws = new WelcomeScreen();
            ws.Show();
            Close();
        }

        public bool CheckForNullValues()
        {
            if (name.Length == 0 || email.Length == 0 || password1.Length == 0 || password2.Length == 0 || phone.Length == 0 || userId.Length == 0)
            {
                return false;
            }
            return true;
        }

        public bool ValidateValues()
        {
            bool res = false;

            res = Validation.ValidateName(name);

            if (res)
            {
                res = Validation.ValidateEmail(email);

                if (res)
                {
                    res = Validation.ValidatePhone(phone);

                    if (res)
                    {
                        res = Validation.ValidateId(userId);

                        if (res)
                        {
                            res = Validation.ValidatePasswords(password1, password2);

                            if (res)
                            {
                                return true;
                            }
                            else
                            {
                                createPassField.Text = null;
                                confirmPassField.Text = null;
                                MessageBox.Show("Passwords do not match");
                            }
                        }
                        else
                        {
                            userIdField.Text = null;
                            MessageBox.Show("User Id should be of length 5 and should contain numbers only.");
                        }
                    }
                    else
                    {
                        phoneField.Text = null;
                        MessageBox.Show("Phone number is not valid.");
                    }
                }
                else
                {
                    emailField.Text = null;
                    MessageBox.Show("Please enter a valid Email");
                }
            }
            else
            {
                nameField.Text = null;
                MessageBox.Show("Please enter a valid Name");
            }
            return false;
        }

        public void InitializeValues()
        {
            name = nameField.Text.ToString();
            email = emailField.Text.ToString();
            phone = phoneField.Text.ToString();
            userId = userIdField.Text.ToString();
            password1 = createPassField.Text.ToString();
            password2 = confirmPassField.Text.ToString();
        }
    }
}
