﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectHotelApp
{
    public partial class AdminNewHotel : Form
    {
        string name = null, address = null, landmark = null, city = null, hotelId = null;
        string rating = null, pincode = null, ac1 = null, ac2 = null, ac3 = null;
        string nonac1 = null, nonac2 = null, nonac3 = null, total = null;

        public AdminNewHotel()
        {
            InitializeComponent();
        }

        // Create Button Clicked
        private void button1_Click(object sender, EventArgs e)
        {
            bool isValid = CheckForNullValues();

            if (isValid) // If no field is null
            {
                InitializeValues(); // Initializes the values

                isValid = ValidateValues(); // Validate the values

                if (isValid)
                {
                    isValid = Database.CheckIfHotelExists(hotelId); // returns true is a Hotel with this Id already exists

                    if(!(isValid))
                    {
                        total = CountTotalRooms();

                        // Add these values to the Hotoel Database, function returns 1 on successfull operation
                        int k = Database.AddNewHotelToDB(hotelId, name, address, landmark, city, rating, pincode, ac1, ac2, ac3, nonac1, nonac2, nonac3, total);

                        if (k == 1)
                        {
                            MessageBox.Show("Successfully created Hotel.");
                            ResetValues();
                        }
                        else
                        {
                            MessageBox.Show("Sorry, an error occurred.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Hotel Id already registered");
                        textBox8.Text = null;
                    }
                }
            }
            else
            {
                MessageBox.Show("All fields are mandatory.");
            }
        }

        // Back button clicked
        private void button2_Click(object sender, EventArgs e)
        {
            AdminPage adminPage = new AdminPage();
            adminPage.Show();
            Close();
        }

        public void InitializeValues()
        {
            name = textBox1.Text;
            landmark = textBox3.Text;
            city = comboBox1.Text;
            address = textBox7.Text;
            hotelId = textBox8.Text;
            rating = ratingComboBox.Text;
            pincode = textBox6.Text;
            ac1 = acroom1.Text;
            ac2 = acroom2.Text;
            ac3 = acroom3.Text;
            nonac1 = nonacroom1.Text;
            nonac2 = nonacroom2.Text;
            nonac3 = nonacroom3.Text;
        }

        public bool ValidateValues()
        {
            bool isValid = Validation.ValidateId(hotelId);

            if (isValid)
            {
                isValid = Validation.ValidateName(name);

                if (isValid)
                {
                    isValid = Validation.ValidateName(landmark);

                    if (isValid)
                    {
                        isValid = Validation.ValidatePincode(pincode);

                        if (isValid)
                        {
                            isValid = Validation.ValidateAddress(address);

                            if (isValid)
                            {
                                var myRooms = GetRoomData();
                                int wrongItem = 0;

                                isValid = Validation.ValidateRoomNumber(myRooms, ref wrongItem);

                                if (isValid)
                                {
                                    return true;
                                }
                                else
                                {
                                    if (wrongItem == 0)
                                    {
                                        acroom1.Text = null;
                                    }
                                    if (wrongItem == 1)
                                    {
                                        acroom2.Text = null;
                                    }
                                    if (wrongItem == 2)
                                    {
                                        acroom3.Text = null;
                                    }
                                    if (wrongItem == 3)
                                    {
                                        nonacroom1.Text = null;
                                    }
                                    if (wrongItem == 4)
                                    {
                                        nonacroom2.Text = null;
                                    }
                                    if (wrongItem == 5)
                                    {
                                        nonacroom3.Text = null;
                                    }
                                    MessageBox.Show("Enter a valid value for room number.");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Address must not contain any special charcter other than [.,/].");
                                textBox7.Text = null;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Invalid Pincode.");
                            textBox6.Text = null;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Landmark is not valid.");
                        textBox3.Text = null;
                    }
                }
                else
                {
                    MessageBox.Show("Name is not valid.");
                    textBox1.Text = null;
                }
            }
            else
            {
                MessageBox.Show("Hotel Id should be 5 digits long and should contain numbers only.");
                textBox8.Text = null;
            }
            return false;
        }

        public bool CheckForNullValues()
        {
            if(textBox1.Text == string.Empty || textBox3.Text == string.Empty || comboBox1.SelectedIndex == -1 || textBox7.Text == string.Empty || textBox8.Text == string.Empty || ratingComboBox.SelectedIndex == -1 || textBox6.Text == string.Empty || acroom1.Text == string.Empty || acroom2.Text == string.Empty || acroom3.Text == string.Empty || nonacroom1.Text == string.Empty || nonacroom2.Text == string.Empty || nonacroom3.Text == string.Empty)
            {
                return false;
            }
            return true;
        }

        public string CountTotalRooms()
        {
            return (int.Parse(ac1) + int.Parse(ac2) + int.Parse(ac3) + int.Parse(nonac1) + int.Parse(nonac2) + int.Parse(nonac3)).ToString();
        }

        public List<string> GetRoomData()
        {
            var myRooms = new List<String>();

            myRooms.Add(ac1);
            myRooms.Add(ac2);
            myRooms.Add(ac3);
            myRooms.Add(nonac1);
            myRooms.Add(nonac2);
            myRooms.Add(nonac3);

            return myRooms;
        }

        public void ResetValues()
        {
            textBox1.Text = null;
            textBox3.Text = null;
            comboBox1.Text = "Select City";
            ratingComboBox.Text = "Select Rating";
            textBox6.Text = null;
            textBox7.Text = null;
            textBox8.Text = null;
            acroom1.Text = null;
            acroom2.Text = null;
            acroom3.Text = null;
            nonacroom1.Text = null;
            nonacroom2.Text = null;
            nonacroom3.Text = null;
        }
    }
}