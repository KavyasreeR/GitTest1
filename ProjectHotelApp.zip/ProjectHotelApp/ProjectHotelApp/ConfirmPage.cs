﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectHotelApp
{
    public partial class ConfirmPage : Form
    {
        int hotelId = 0, beds = 0, rooms = 0, amount = 0;
        string cool = null, cInDate = null, cOutDate = null, userId = null, bDate = null;

        public ConfirmPage(int hotelId, int beds, string cool, int rooms, string checkInDate, string checkOutDate, string userId)
        {
            InitializeComponent();
            InitializeValues(hotelId,beds,cool,rooms,checkInDate,checkOutDate,userId);
            ShowConfirmationDetails();
        }

        public void ShowConfirmationDetails()
        {
            ShowHotelDetails();
            ShowBookingDetails();
            ShowCustomerDetails();
            ShowBookingDate();
        }

        public void ShowHotelDetails()
        {
            var myHotelDetails = Database.FindHotelByIdAndReturnNameAddressCity(hotelId);
            hotelNameLabel.Text += myHotelDetails[0];
            hotelAddress.Text += myHotelDetails[1];
            hotelCityName.Text += myHotelDetails[2];
        }

        public void ShowBookingDetails()
        {
            bookingBeds.Text += beds;
            bookingCool.Text += cool;
            bookingRooms.Text += rooms;
            bookingCheckIn.Text += cInDate;
            bookingCheckOut.Text += cOutDate;
            CalculateAmount();
        }

        public void CalculateAmount()
        {
            // Code for calculating the amount
            //
            //
            //
            amount = 6000;
            payLabelAmount.Text = amount.ToString();
        }

        public void ShowBookingDate()
        {
            DateTime currDate = DateTime.Now;
            bDate = currDate.ToString("dd/MM/yyyy");
            bookingDateLabel.Text = bDate;
        }

        public void ShowCustomerDetails()
        {
            var myDetails = Database.FindUserByIdAndReturnNamePhone(userId);

            customerName.Text += myDetails[0].ToString();
            customerPhone.Text += myDetails[1].ToString();
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cancelling ... Redirecting back to the Dashboard.");
            UserPage lf = new UserPage(userId); 
            lf.Show();
            Close();
        }

        private void confirmBooking_Click(object sender, EventArgs e)
        {
            int k = Database.CreateNewBooking(hotelId,beds,cool,rooms,cInDate,cOutDate,userId,bDate,amount);

            if(k == 1)
            {
                MessageBox.Show("Booking completed successfully\n\nRedirecting to the Dashboard.");
                UserPage lf = new UserPage(userId);
                lf.Show();
                Close();
            }
            else
            {
                MessageBox.Show("Sorry an error occurred.");
            }
        }

        public void InitializeValues(int hotelId, int beds, string cool, int rooms, string checkInDate, string checkOutDate, string userId)
        {
            this.hotelId = hotelId;
            this.beds = beds;
            this.cool = cool;
            this.rooms = rooms;
            this.userId = userId;
            cInDate = checkInDate;
            cOutDate = checkOutDate;
        }
    }
}
