﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectHotelApp
{
    public partial class WelcomeScreen : Form
    {
        public WelcomeScreen()
        {
            InitializeComponent();
        }

        private void signUpLabel_Click(object sender, EventArgs e)
        {
            UserRegistration ug = new UserRegistration();
            ug.Show();
            Hide();
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            bool isValid = ValidateValues();

            if (isValid)
            {
                isValid = Database.FindUserById(userId.Text);

                if (isValid)
                {
                    isValid = Database.CheckIfPasswordCorrect(userId.Text,userPass.Text);

                    if (isValid)
                    {
                        UserPage userPage = new UserPage(userId.Text);
                        userPage.Show();
                        Hide();
                    }
                    else
                    {
                        MessageBox.Show("Incorrect Password.");
                        userPass.Text = null;
                    }
                }
                else
                {
                    MessageBox.Show("User does not exist.");
                    userId.Text = null;
                    userPass.Text = null;
                }
            }
            else
            {
                MessageBox.Show("Please enter your login credentials.");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
            Close();
        }

        public bool ValidateValues()
        {
            if(!(userId.Text.Length == 0 || userPass.Text.Length == 0))
            {
                return true;
            }
            return false;
        }

        private void adminLogin_Click(object sender, EventArgs e)
        {
            AdminLogin al = new AdminLogin();
            al.Show();
            Hide();
        }
    }
}
