﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectHotelApp
{
    public partial class AdminPage : Form
    {
        public AdminPage()
        {
            InitializeComponent();
            AddValuesToHotelComboBox();
        }

        // Admin initiates request to add a new Hotel to the DB
        private void button3_Click(object sender, EventArgs e)
        {
            AdminNewHotel newHotel = new AdminNewHotel();
            newHotel.Show();
            Hide();
        }

        // Logout Button clicked
        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Logging out ... Redirecting back to Login page.");
            AdminLogin adminLogin = new AdminLogin();
            adminLogin.Show();
            Close();
        }

        private void selectHotelCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedHotelString = selectHotelCombo.Text;
            int selectedHotel = int.Parse(selectedHotelString.Substring(0, 5)); // Grab Hotel ID from the Combobox selected String

            ResetResultBoxValues();

            FindRoomsInHotel(selectedHotel);
        }

        public void ResetResultBoxValues()
        {
            acroom1.Text = null;
            acroom2.Text = null;
            acroom3.Text = null;
            nonacroom1.Text = null;
            nonacroom2.Text = null;
            nonacroom3.Text = null;
            totalRooms.Text = null;
        }

        public void FindRoomsInHotel(int selectedHotel)
        {
            string result = Database.FindHotelById(selectedHotel);

            if (result != null)
            {
                ShowValuesToAdmin(result);
            }
        }

        public void ShowValuesToAdmin(string result)
        {
            resultBox.Visible = true;

            string[] rooms = result.Split(' '); // Split the Room numbers 

            AssignValues(rooms); // Assign values accordingly

            totalRooms.Text = "Total Rooms available : " + GetTotalRooms(rooms);
        }

        public void AddValuesToHotelComboBox()
        {
            bool hasHotel = false;

            List<string> myHotels = Database.SelectAllHotels(ref hasHotel);

            if (hasHotel)
            {
                label3.Text = "Select a hotel from the list below to see the no. of rooms available :";
                selectHotelCombo.Visible = true;
                selectHotelCombo.Text = "---- Select Hotel ----";

                foreach (var value in myHotels)
                {
                    selectHotelCombo.Items.Add(value);
                }
            }
            else
            {
                label3.Text = "Sorry there are no Hotels at this time.";
            }
        } 

        public void AssignValues(string[] rooms)
        {
            acroom1.Text = "1 Bed AC Rooms : " + rooms[0];
            acroom2.Text = "2 Bed AC Rooms : " + rooms[1];
            acroom3.Text = "3 Bed AC Rooms : " + rooms[2];
            nonacroom1.Text = "1 Bed Non-AC Rooms : " + rooms[3];
            nonacroom2.Text = "2 Bed Non-AC Rooms : " + rooms[4];
            nonacroom3.Text = "3 Bed Non-AC Rooms : " + rooms[5];
        }

        public string GetTotalRooms(string[] rooms)
        {
            return (int.Parse(rooms[0]) + int.Parse(rooms[1]) + int.Parse(rooms[2]) + int.Parse(rooms[3]) + int.Parse(rooms[4]) + int.Parse(rooms[5])).ToString();
        }

        private void bookingsButton_Click(object sender, EventArgs e)
        {
            bool hasBooking = false;

            var bookings = Database.SelectAllBookings(ref hasBooking);

            if (!hasBooking)
            {
                bookingPanel.Visible = false;
                failureLabel.Visible = true;
                failureLabel.Text = "No bookings have been done so far.";
                customerBookingBox.Visible = false;
            }
            else
            {
                customerBookingBox.Visible = true;
                failureLabel.Visible = false;
                bookingPanel.Visible = true;
                bookingsButton.Visible = false;
                label2.Text = "Take a look at the bookings below :";
                foreach (var value in bookings)
                {
                    customerBookingBox.Items.Add(value);
                }
            }
        }
    }
}
