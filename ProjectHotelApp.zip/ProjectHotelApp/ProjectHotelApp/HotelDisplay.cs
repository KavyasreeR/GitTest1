﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectHotelApp
{
    public partial class HotelDisplay : Form
    {
        string city = null, userId = null;
        int rating = 0;
        int hotelId = 0;

        //check the object creation of forms
        public HotelDisplay(string userId, string city, int rating)
        {
            InitializeComponent();
            this.city = city;
            this.rating = rating;
            this.userId = userId;
            CheckIfHotelExists();
        }

        private void hotelCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            hotelId = int.Parse(hotelCombo.Text.Substring(0, 5));
            DisplayHotelDetails();
        }
        
        public void CheckIfHotelExists()
        {
            bool hasHotel = false;

            var myHotels = Database.SearchHotelsWithCityAndRating(city, rating, ref hasHotel);

            if (hasHotel)
            {
                panel1.Visible = true;
                foreach(var value in myHotels)
                {
                    hotelCombo.Items.Add(value);
                }
            }
            else
            {
                failureLabel.Text = "Sorry, no results match that criteria.";
                panel1.Visible = false;
            }
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            UserPage lf = new UserPage(userId); // Replace with dashboard class
            lf.Show();
            Close();
        }

        private void nextButton_Click(object sender, EventArgs e)
        {
            HotelBooking hb = new HotelBooking(userId,hotelId);
            hb.Show();
            Close();
        }

        public void DisplayHotelDetails()
        {
            var hotelDetails = Database.FindHotelByIdAndReturnNameAddressCity(hotelId);

            hotelNameLabel.Text = "Hotel Name : " + hotelDetails[0];
            roomChargeLabel.Text = "Charge per head per night : Rs. 6000";
            hotelAddressLabel.Text = "Address : " + hotelDetails[1];
            hotelCityLabel.Text = "City : " + hotelDetails[2];
        }
    }
}
