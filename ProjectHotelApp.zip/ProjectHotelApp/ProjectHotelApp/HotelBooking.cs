﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectHotelApp
{
    public partial class HotelBooking : Form
    {
        int hotelId = 0, beds = 0, rooms = 0;
        string cool = null, checkInDate = null, checkOutDate = null, userId = null;
        DateTime cin_date, cout_date;

        public HotelBooking(string userId, int hotelId)
        {
            InitializeComponent();
            this.hotelId = hotelId;
            this.userId = userId;
            PrintHotelName();
        }

        private void Cmb_Beds_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            beds = int.Parse(Cmb_Beds.Text);
        }

        private void Cmb_Cool_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            cool = Cmb_Cool.Text;
        }

        private void checkInButton_Click(object sender, EventArgs e)
        {
            cin_date = Calendar.SelectionRange.Start.ToLocalTime();

            bool isValid = Validation.ValidateCheckInDate(cin_date);

            if (isValid)
            {
                checkInDate = cin_date.ToString("dd/MM/yyyy");
                checkInDateLabel.Text = "Check in date : " + checkInDate;
                checkInDateLabel.Visible = true;
                checkInButton.Visible = false;
                checkOutButton.Visible = true;
                resetDates.Visible = true;
            }
            else
            {
                MessageBox.Show("Please select a valid check in date.");
            }
        }

        private void checkOutButton_Click(object sender, EventArgs e)
        {
            cout_date = Calendar.SelectionRange.Start.ToLocalTime();

            bool isValid = Validation.ValidateCheckOutDate(cin_date, cout_date);

            if (isValid)
            {
                checkOutDate = cout_date.ToString("dd/MM/yyyy");
                checkOutDateLabel.Text = "Check out date : " + checkOutDate;
                checkOutButton.Visible = false;
                checkOutDateLabel.Visible = true;
                nextButton.Visible = true;
            }
            else
            {
                MessageBox.Show("Please select a valid check out date.");
            }
        }

        private void resetDates_Click(object sender, EventArgs e)
        {
            checkInDate = null;
            checkOutDate = null;
            checkInDateLabel.Visible = false;
            checkOutDateLabel.Visible = false;
            checkOutButton.Visible = false;
            checkInButton.Visible = true;
        }

        private void nextButton_Click(object sender, EventArgs e)
        {
            ConfirmPage cf = new ConfirmPage(hotelId, beds, cool, rooms, checkInDate, checkOutDate, userId);
            cf.Show();
            Close();
        }

        private void Cmb_Room_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            rooms = int.Parse(Cmb_Room.Text);
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            if (beds != 0 && cool != null && rooms != 0)
            {
                DisplayMessageOrPanel();
            }
            else
            {
                MessageBox.Show("Please select all the fields.");
            }
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cancelling ... Redirecting back to the Dashboard.");
            UserPage lf = new UserPage(userId);
            lf.Show();
            Close();
        }

        public void PrintHotelName()
        {
            var name = Database.FindHotelByIdAndReturnName(hotelId);
            hotelNameLabel.Text = name;
        }

        public void DisplayMessageOrPanel()
        {
            if (beds != 0 && cool != null && rooms != 0)
            {
                bool hasRoom = Database.CheckRoomAvailabilityById(hotelId, beds, cool, rooms);

                if (hasRoom)
                {
                    failureLabel.Visible = false;
                    successPanel.Visible = true;
                }
                else
                {
                    successPanel.Visible = false;
                    failureLabel.Visible = true;
                }
            }
        }
    }
}
