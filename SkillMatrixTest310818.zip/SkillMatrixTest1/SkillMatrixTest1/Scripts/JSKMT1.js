﻿function addRP()
{
    var cnfmVal = confirm("confirm registration");
    if (cnfmVal == true) {
        //document.writeln("user wanst to continue");
        return true;
        
    }
    else {
       // document.write("user don't want to proceed");
        return false;
    }   
}

function ddselectCow() {
    var cowstat = document.getElementById("CkBxCowPjRp").checked;

    if (cowstat == true) {
        var cowmod = document.getElementById("CkBxGrpCoWModRP");
        if (cowmod.style.display == "none") {
            cowmod.style.display = "block";
        }
    }
     
    
    //alert("a value is changed in dd menu");

}

function ddselectEam() {
    var eamstat = document.getElementById("CkBxEamRP").checked;

    if (eamstat == true) {
        confirm("want to continue adding modules");
        var eammod = document.getElementById("CkBxGrpEAMModRP");
        if (eammod.style.display == "none") {
            eammod.style.display = "block";
        }
    }
   
}