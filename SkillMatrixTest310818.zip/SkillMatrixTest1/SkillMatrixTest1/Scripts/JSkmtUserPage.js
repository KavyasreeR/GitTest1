﻿function cowModuleShowUP() {
    

    var CowCkBXstat = document.getElementById("CkBxCoWPJUP").checked;
    if (CowCkBXstat== true) {

        var CoWModstat = document.getElementById("divCowMUP");
        
        if (CoWModstat.style.display == "none") {
            CoWModstat.style.display = "block";
        }
    }
      

}